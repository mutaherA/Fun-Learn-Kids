/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { GoogleGenAI, Type } from '@google/genai';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
const root = document.getElementById('root');

type Category = 'Alphabets' | 'Numbers' | 'Colors' | 'Shapes';
type Item = {
  display: string;
  spoken: string;
  style?: string;
};

interface AppState {
  currentScreen: 'home' | 'category';
  activeCategory: Category | null;
  items: Item[];
  isLoading: boolean;
}

const state: AppState = {
  currentScreen: 'home',
  activeCategory: null,
  items: [],
  isLoading: false,
};

// --- Speech Synthesis ---
const synth = window.speechSynthesis;
let voices: SpeechSynthesisVoice[] = [];

function populateVoices() {
    voices = synth.getVoices();
}
populateVoices();
if (synth.onvoiceschanged !== undefined) {
    synth.onvoiceschanged = populateVoices;
}

function speak(text: string) {
    if (synth.speaking) {
        synth.cancel();
    }
    const utterance = new SpeechSynthesisUtterance(text);
    // Find a friendly, female voice. Fallback to default.
    const femaleVoice = voices.find(voice => voice.name.includes('Female') && voice.lang.startsWith('en'));
    utterance.voice = femaleVoice || voices.find(voice => voice.lang.startsWith('en')) || voices[0];
    utterance.pitch = 1.2;
    utterance.rate = 0.9;
    utterance.volume = 1;
    synth.speak(utterance);
}

// --- Data Fetching with Gemini ---
async function fetchCategoryData(category: Category): Promise<Item[]> {
    const prompts = {
        'Alphabets': "Generate a JSON array for the English alphabet from A to Z. Each object should have a 'display' property (e.g., 'A') and a 'spoken' property (e.g., 'A for Apple').",
        'Numbers': "Generate a JSON array for numbers from 1 to 20. Each object should have a 'display' property (e.g., '1') and a 'spoken' property (e.g., 'One').",
        'Colors': "Generate a JSON array of 12 common colors. Each object should have a 'display' property (the color name), a 'spoken' property (e.g., 'This is Red'), and a 'style' property (the hex code).",
        'Shapes': "Generate a JSON array of 8 basic geometric shapes. Each object should have a 'display' property (the shape name), and a 'spoken' property (e.g., 'This is a Circle')."
    };
    
    const schemas = {
        'Alphabets': { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { display: { type: Type.STRING }, spoken: { type: Type.STRING } } } },
        'Numbers': { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { display: { type: Type.STRING }, spoken: { type: Type.STRING } } } },
        'Colors': { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { display: { type: Type.STRING }, spoken: { type: Type.STRING }, style: { type: Type.STRING } } } },
        'Shapes': { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { display: { type: Type.STRING }, spoken: { type: Type.STRING } } } },
    };

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompts[category],
            config: {
                responseMimeType: "application/json",
                responseSchema: schemas[category],
            }
        });
        const jsonString = response.text.trim();
        return JSON.parse(jsonString);
    } catch (error) {
        console.error("Failed to fetch data from Gemini API:", error);
        // Fallback data
        return [{ display: 'Error', spoken: 'Oh no, something went wrong.' }];
    }
}

// --- Navigation ---
async function navigateToCategory(category: Category) {
    state.currentScreen = 'category';
    state.activeCategory = category;
    state.isLoading = true;
    render();

    const items = await fetchCategoryData(category);
    state.items = items;
    state.isLoading = false;
    render();
}

function navigateHome() {
    state.currentScreen = 'home';
    state.activeCategory = null;
    state.items = [];
    render();
}

// --- Rendering ---
function renderHomeScreen() {
    root.innerHTML = `
        <div class="app-container">
            <h1 class="app-title">Fun Learn Kids</h1>
            <div class="category-grid">
                <div class="category-card alphabets" data-category="Alphabets">
                    <div class="card-icon">🔤</div>
                    <div class="card-title">Alphabets</div>
                </div>
                <div class="category-card numbers" data-category="Numbers">
                    <div class="card-icon">🔢</div>
                    <div class="card-title">Numbers</div>
                </div>
                <div class="category-card colors" data-category="Colors">
                    <div class="card-icon">🎨</div>
                    <div class="card-title">Colors</div>
                </div>
                <div class="category-card shapes" data-category="Shapes">
                    <div class="card-icon">🔷</div>
                    <div class="card-title">Shapes</div>
                </div>
            </div>
        </div>
    `;
    document.querySelectorAll('.category-card').forEach(card => {
        card.addEventListener('click', () => {
            const category = card.getAttribute('data-category') as Category;
            navigateToCategory(category);
        });
    });
}

function renderCategoryScreen() {
    const itemGridHtml = state.items.map(item => `
        <div class="item-card" 
             style="${item.style ? `background-color:${item.style}; color: white; text-shadow: 1px 1px 2px black;` : ''}"
             data-spoken="${item.spoken}">
            ${item.display}
        </div>
    `).join('');

    root.innerHTML = `
        <div class="category-view">
            <div class="header">
                <button class="back-button">← Back</button>
                <h2 class="category-title">${state.activeCategory}</h2>
            </div>
            ${state.isLoading ? '<div class="loader"></div>' : `<div class="item-grid">${itemGridHtml}</div>`}
        </div>
    `;

    document.querySelector('.back-button')?.addEventListener('click', navigateHome);
    
    document.querySelectorAll('.item-card').forEach(card => {
        card.addEventListener('click', () => {
            const spokenText = card.getAttribute('data-spoken');
            if (spokenText) {
                speak(spokenText);
                card.classList.add('tapped');
                setTimeout(() => card.classList.remove('tapped'), 500);
            }
        });
    });
}


function render() {
    if (root) {
        root.innerHTML = ''; // Clear previous content
        if (state.currentScreen === 'home') {
            renderHomeScreen();
        } else if (state.currentScreen === 'category') {
            renderCategoryScreen();
        }
    }
}

// Initial Render
render();
